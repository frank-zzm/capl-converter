var searchData=
[
  ['timestamptype',['timestampType',['../class_asc_1_1_asc_file_properties.html#a77df9f852a558f90ac8384f1ea821ab2',1,'Asc::AscFileProperties']]],
  ['triggerblocktimeanddate',['triggerBlockTimeAndDate',['../class_asc_1_1_asc_file_properties.html#a508dad3d94327c72fb27482750b076af',1,'Asc::AscFileProperties']]]
];
