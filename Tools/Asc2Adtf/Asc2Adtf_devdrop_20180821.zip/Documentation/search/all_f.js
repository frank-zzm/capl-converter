var searchData=
[
  ['version',['version',['../class_asc_1_1_asc_file_properties.html#adc523e6b42c2f1c897950135c838d837',1,'Asc::AscFileProperties']]]
];
