var searchData=
[
  ['dateandtime',['DateAndTime',['../struct_asc_1_1_date_and_time.html',1,'DateAndTime'],['../struct_asc_1_1_date_and_time.html#a8a8e9830571b8e2d7ab7b46c24a5520f',1,'Asc::DateAndTime::dateAndTime()']]],
  ['dec',['Dec',['../class_asc_1_1_asc_file_properties.html#a450696a95d6cb29d7723838846948340ad207b4e0bce42a8f1555ce3a05e287f6',1,'Asc::AscFileProperties']]]
];
