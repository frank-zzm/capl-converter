var searchData=
[
  ['base',['Base',['../class_asc_1_1_asc_file_properties.html#a450696a95d6cb29d7723838846948340',1,'Asc::AscFileProperties']]]
];
