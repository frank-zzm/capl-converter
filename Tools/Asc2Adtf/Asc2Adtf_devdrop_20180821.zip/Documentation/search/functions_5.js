var searchData=
[
  ['openfile',['OpenFile',['../class_asc_1_1_asc_file_reader.html#adfdc38c052ddf47ddaeb52eb03c0bb43',1,'Asc::AscFileReader::OpenFile()'],['../class_asc_1_1_i_asc_file_reader.html#ab98408ae732bfe397064116d950d38c1',1,'Asc::IAscFileReader::OpenFile()']]]
];
