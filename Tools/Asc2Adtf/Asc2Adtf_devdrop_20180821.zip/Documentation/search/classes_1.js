var searchData=
[
  ['dateandtime',['DateAndTime',['../struct_asc_1_1_date_and_time.html',1,'Asc']]]
];
