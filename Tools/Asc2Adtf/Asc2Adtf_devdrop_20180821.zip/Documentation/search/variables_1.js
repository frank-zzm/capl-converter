var searchData=
[
  ['dateandtime',['dateAndTime',['../struct_asc_1_1_date_and_time.html#a8a8e9830571b8e2d7ab7b46c24a5520f',1,'Asc::DateAndTime']]]
];
