var searchData=
[
  ['getcorrecttimestampvalue',['GetCorrectTimestampValue',['../class_asc_1_1_asc_common_parser.html#a838697e5e4da25022c8f32f75007f9e5',1,'Asc::AscCommonParser::GetCorrectTimestampValue()'],['../class_asc_1_1_i_asc_parser.html#a42e2cabdbb668049319ef768007ee098',1,'Asc::IAscParser::GetCorrectTimestampValue()']]],
  ['getfileproperties',['GetFileProperties',['../class_asc_1_1_asc_file_reader.html#a77dd1f6600179616ef51aea87c2e1c54',1,'Asc::AscFileReader::GetFileProperties()'],['../class_asc_1_1_i_asc_file_reader.html#af74923b7fdea1036be6c241b275950b5',1,'Asc::IAscFileReader::GetFileProperties()']]]
];
