var searchData=
[
  ['settings',['Settings',['../struct_asc_1_1_settings.html',1,'Asc']]]
];
