var searchData=
[
  ['timestamptype',['TimestampType',['../class_asc_1_1_asc_file_properties.html#a5b99e69700d73fbb898014393e993ca0',1,'Asc::AscFileProperties::TimestampType()'],['../class_asc_1_1_asc_file_properties.html#a77df9f852a558f90ac8384f1ea821ab2',1,'Asc::AscFileProperties::timestampType()']]],
  ['triggerblocktimeanddate',['triggerBlockTimeAndDate',['../class_asc_1_1_asc_file_properties.html#a508dad3d94327c72fb27482750b076af',1,'Asc::AscFileProperties']]]
];
