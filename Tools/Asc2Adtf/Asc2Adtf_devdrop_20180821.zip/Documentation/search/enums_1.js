var searchData=
[
  ['timestamptype',['TimestampType',['../class_asc_1_1_asc_file_properties.html#a5b99e69700d73fbb898014393e993ca0',1,'Asc::AscFileProperties']]]
];
