var searchData=
[
  ['isrecordingok',['IsRecordingOk',['../class_asc_1_1_file_recorder_monitor.html#a837a192fe32892db4ef96f1440ec0fab',1,'Asc::FileRecorderMonitor']]]
];
