var searchData=
[
  ['filetimeanddate',['fileTimeAndDate',['../class_asc_1_1_asc_file_properties.html#aac49395ad208cd7f5692232da79d1944',1,'Asc::AscFileProperties']]]
];
